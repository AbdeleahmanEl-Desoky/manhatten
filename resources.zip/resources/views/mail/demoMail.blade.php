<!DOCTYPE html>
<html>
<head>
    <title>Manhattan NYC</title>
</head>
<body>

    <h1>{{ $mailData['title'] }}</h1>
    <p>{{ $mailData['from'] }}</p>
    <p>{{ $mailData['body'] }}</p>
</body>
</html>
