<div class="row">
    <div class="col-12 col-lg-12 p-2 m-auto text-center bg-light one_title">

        <a class="link_image" href="{{route('times_square')}}"><img class="img_header"
                src="{{ asset('website/assets/images/header/buttons/Times Square, NYC.jpg') }}" alt=""></a>

        <a class="link_image" href="{{route('vessel')}}"><img class="img_header"
                src="{{ asset('website/assets/images/header/buttons/vessel.jpg') }}" alt=""></a>

        <a class="link_image" href="{{route('home')}}"><img class="img_header"
                    src="{{ asset('website/assets/images/header/buttons/manhattan.jpg') }}" alt=""></a>

        <a class="link_image" href="{{route('one_world')}}"><img class="img_header"
                        src="{{ asset('website/assets/images/header/buttons/One World Trade Center, NYC.jpg') }}" alt=""></a>

        <a class="link_image" href="{{route('rockefeller')}}"><img class="img_header"
                            src="{{ asset('website/assets/images/header/buttons/Rockefeller Center, New York City.jpg') }}" alt=""></a>

            </div>
</div>
